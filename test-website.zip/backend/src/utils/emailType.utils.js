module.exports = {
    EmailVerify: 'EmailVerify',
    ResetPassword: 'ResetPassword'
}